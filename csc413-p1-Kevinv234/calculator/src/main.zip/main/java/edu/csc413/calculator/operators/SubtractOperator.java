package edu.csc413.calculator.operators;
import edu.csc413.calculator.evaluator.Operand;

public class SubtractOperator extends Operator{

    //construct Subtract operator class
    public SubtractOperator(){

    }

    //override priority for SubtractOperator
    @Override
    public int priority(){
        return 1;
    }

    //override execute function for SubtractOperator
    @Override
    public Operand execute(Operand op1, Operand op2){
        Operand total = new Operand(op1.getValue() - op2.getValue());
        return total;
    }
}
