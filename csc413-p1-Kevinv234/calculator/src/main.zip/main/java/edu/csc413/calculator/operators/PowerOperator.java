package edu.csc413.calculator.operators;
import edu.csc413.calculator.evaluator.Operand;

public class PowerOperator extends Operator{

    //construct the SubtractionOperator class
    public PowerOperator(){

    }

    //create the priority and override it as well
    @Override
    public int priority(){
        return 3;
    }

    //override execute for PowerOperator
    @Override
    public Operand execute(Operand op1, Operand op2){

        //create value
        int total = 1;

        //multiply and loop the nth
        for(int i = 0; i < op2.getValue(); i++){
            total *= op1.getValue();
        }

        //create new Operand and return total
        Operand powerTotal = new Operand(total);
        return powerTotal;
    }
}
