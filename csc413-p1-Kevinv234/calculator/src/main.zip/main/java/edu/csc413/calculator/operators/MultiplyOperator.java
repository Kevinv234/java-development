package edu.csc413.calculator.operators;

import edu.csc413.calculator.evaluator.Operand;

public class MultiplyOperator extends Operator {

    //construct the SubtractionOperator class
    public MultiplyOperator(){

    }

    //create the priority and override it as well
    @Override
    public int priority(){
        return 2;
    }

    // override execute function
    // return total
    @Override
    public Operand execute(Operand op1, Operand op2){
        Operand total = new Operand( op1.getValue() * op2.getValue());
        return total;
    }

}